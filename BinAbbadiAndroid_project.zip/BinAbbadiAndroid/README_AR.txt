مشروع أندرويد: بن عبادي للمواد الكهربائية

هذا مشروع Android Studio (المصدر) وليس ملف APK جاهزًا. لم تتوفر في بيئة إنشاء الملفات أدوات Android SDK/Gradle اللازمة لتجميع APK هنا.

لإنشاء APK:
1. نزّل Android Studio على كمبيوتر.
2. فك ضغط BinAbbadiAndroid.zip.
3. افتح المجلد BinAbbadiAndroid من Android Studio.
4. انتظر Gradle Sync، ثم اختر Build > Build APK(s).
5. ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk.

قبل الاستخدام التجاري:
- افتح app/src/main/assets/index.html وابحث عن WHATSAPP_NUMBER وضع رقم المحل بصيغة دولية دون + أو مسافات.
- عدّل المنتجات والأسعار التجريبية.
- هذا إصدار أولي؛ لا يتضمن الدفع الإلكتروني أو إدارة المخزون.

معرّف التطبيق: com.binabbadi.electrical
الحد الأدنى لأندرويد: Android 6.0 (API 23)
